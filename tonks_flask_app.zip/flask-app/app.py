from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage
import os
import subprocess
app = Flask(__name__)

@app.route('/upload')
def upload_file():
   return render_template('upload.html')
	
@app.route('/uploader', methods = ['GET', 'POST'])
def uploader():
   if request.method == 'POST':
      f = request.files['file']
      f.save(secure_filename(f.filename))
      num_correct= subprocess.check_output("cs4740_S21_pa2/autograde.py")
      return str(num_correct)
		
if __name__ == '__main__':
   app.run(debug = True, host="0.0.0.0")
