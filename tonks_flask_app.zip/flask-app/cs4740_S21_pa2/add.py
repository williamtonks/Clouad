int1 = int(input("Input integer 1: ")) 
int2 = int(input("Input integer 2: "))
print ("the sum is " + str(int1 + int2))
