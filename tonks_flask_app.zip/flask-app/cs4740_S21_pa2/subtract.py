int1 = int(input("Input integer 1: ")) 
int2 = int(input("Input integer 2: "))
print ("the result is " + str(int1 - int2))
